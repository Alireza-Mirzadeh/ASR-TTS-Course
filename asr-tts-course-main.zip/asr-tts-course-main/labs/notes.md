## Instructions (to tell the students on the first lab)

- Evaluation: written 60% + labs 40%. Each lab has 4 exercices (1 exercice = 1 point, hence a total on a 20 scale)
- For the labs: upload the completed notebook (code + markdown comments if needed) on Arche (deadline end of the week)
- When asked to "Comment", it means comment the results, not the code
- When the notebook is complete, make a clean run from scratch (restart the kernel) to be sure there's no problem: this is what I'll do to evaluate
- no need to install/import other packages (smells like chat gpt)
- dataset paths are defined at the top of the notebook: students can change it if needed, but only there (not several times in the notebook). It must be simple for adapt it and run the notebook to evaluate.
- The code "quality" (style, comments, efficacy...) is not evaluated; all that matters is that it runs smoothly and does what it's supposed to


## Install
- need python >= 3.9 to get advanced-enough torchmetrics (otherwise, problems)


## TO DO

