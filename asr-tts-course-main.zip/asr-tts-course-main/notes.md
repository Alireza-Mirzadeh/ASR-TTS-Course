Cours ASR actuel (2024)

A p.3: information portée par la parole
A p.4-5: historique + applications ASR
A p.7-10: briques ASR
A p.14-15: production
A p.16-22: perception (raccourcir mais garder pour logmel features, manque delta, PCA/LDA, CMVN)
A p.24-26: visualisation spectrogrammes
A p.27-33: STFT (raccourcir)
A p.34: LPC
A p.35-42: échantillonnage, quantification (raccourcir)
A p.44-48: F0 et formants
A p.50-61: phonèmes, articulation et spectres correspondants
A p.63-68: variabilités (prononciation, voix, cris, bruit)
A p.71-78: features (logmel)
A p.80-88: DTW (peu expliquée)
A p.90-105: HMM (dont Viterbi et Baum-Welch rapidement, manque MAP speaker adaptation)
A p.108-117: variation prononciation
A p.118-126: N-grams
A p.128-139: lexique, modèle langage (pas exemple précis), décodage (pas de beam search)
A p.141-148: calcul WER (non détaillé), mesure confiance ASR (pas mesure de statistical significance)
A p.149-163: robustesse (garder ou pas? il manque la robustesse au locuteur, style de parole, etc.)
A p.165-167: courbes de performance
A p.170-185: rappels DNN (à supprimer)
A p.186-195: TDNN + approche hybride
A p.197-202: modèle de langage
A p.205-241: autres infos (à supprimer)
A p.222-224: articulation phonèmes
A p.227-228: applications ASR
A p.231: ROVER
A p.234-248: programmation dynamique

manque:
intro parole audiovisuelle, gestes
création corpus, data augmentation
discriminative training, WER statistical confidence
subwords/BPE, G2P
auto-supervisé (Wav2vec2, HuBERT, WavLM), fine-tuning CTC, end-to-end attention encoder-decoder/Transducer (Whisper), fine-tuning entropy+CTC, streaming
multilingue, applications, end-to-end ASR+NLP


Cours TTS actuel
L1 p.2-5 information portée par la parole
L1 p.6-7 production
L1 p.8-34 phonèmes, articulation et spectres correspondants
L1 p.35-55: acquisition données articulatoires
L1 p.57-58: modèles articulatoires
L1 p.59-63 synthèse articulatoire
L1 p.64-87 coarticulation
L2 p.3: unités de parole
L2 p.4-11: historique + applications TTS
L2 p.12-23: préparation du texte
L2 p.24-42: synthèse par concaténation
L2 p.43-57: neural TTS en 2 étapes
L2 p.58-61: neural TTS end-to-end
L2 p.62-99: audiovisuel
L2 p.100-121: synthèse expressive
L3 p.2-56: évaluation intelligibilité audiovisuelle + expressivité

manque:
création corpus, briques TTS, GlowTTS, HifiGAN, style tokens, représentations discrètes



Nouveau cours
A p.3: information portée par la parole
L1 p.2-5 information portée par la parole
L2 p.3: unités de parole
A p.14-15: production
L1 p.6-7 production
L1 p.35-55: acquisition données articulatoires (réduire) -> Yves doit en faire en M1
intro parole audiovisuelle, gestes
A p.16-22: perception (raccourcir mais garder pour logmel features)
A p.24-26: visualisation spectrogrammes
A p.44-48: F0 et formants
A p.222-224: articulation phonèmes
A p.50-61: phonèmes, articulation et spectres correspondants
L1 p.8-34 phonèmes, articulation et spectres correspondants
L1 p.64-87 coarticulation
A p.108-117: variation prononciation, lexique
L2 p.12-23: préparation du texte phonétique
subwords/BPE, G2P
130 slides -> 4 heures -> 2 heures max -> 1h20 (IDMC)  2h30 (FST)

no lab on this part

A p.4-5: historique + applications ASR
A p.227-228: applications ASR
A p.63-68: variabilités (prononciation, voix, cris, bruit)
A p.7-10: briques ASR

lab 1 after this

création corpus, data augmentation
A p.35-42: échantillonnage, quantification (raccourcir)
A p.27-33: STFT (raccourcir)
A p.34: LPC
A p.71-78: features (logmel, manque delta, PCA/LDA, CMVN)
A p.80-88: DTW
A p.234-248: programmation dynamique

lab 2 after this

A p.90-105: HMM (dont Viterbi et Baum-Welch rapidement)
discriminative training
MAP speaker adaptation
A p.118-126: N-grams
A p.128-139: modèle langage (pas exemple précis), décodage (pas de beam search)
A p.197-202: modèle de langage
A p.141-148: calcul WER (non détaillé), mesure confiance ASR (pas mesure de statistical significance)
WER statistical confidence
A p.149-163: robustesse (garder ou pas? il manque la robustesse au locuteur, style de parole, etc.)
A p.165-167: courbes de performance
A p.186-195: TDNN + approche hybride
auto-supervisé (Wav2vec2, HuBERT, WavLM), fine-tuning CTC, end-to-end attention encoder-decoder (Whisper), fine-tuning entropy+CTC

lab 3 after this

Transducer, streaming
multilingue, applications, end-to-end ASR+NLP
220 slides -> 8 heures -> un peu plus de 4 heures -> 5h20 (IDMC) 8h30 (FST) <--- 8h ce sera suffisant (ce qui peut être garder pour IA2VR qui ne serait pas abordé en TAL : les parties qui concernent les modèles de langage)

currently: pocketsphinx with isolated digits, write a dedicated lexicon, grammar JSFG (no tutorial) or N-gram, influence of gender + children/adults + noise, no training just testing -> do the same with speechbrain/torchaudio and more realistic dataset
1. use off-the-shelf model
2. alignment
3. fine-tune

L2 p.4-11: historique + applications TTS
briques TTS
création corpus
L1 p.57-58: modèles articulatoires
L1 p.59-63 synthèse articulatoire
L2 p.12-23: préparation du texte prosodie
L2 p.24-42: synthèse par concaténation
L2 p.43-57: neural TTS en 2 étapes (spectrogram+vocoder)

lab 1 here: test phonetization, vocoders, impact of TTS model on quality

L2 p.58-61: neural TTS end-to-end
GlowTTS, HifiGAN, représentations discrètes (attention ils le verront plus tard que réseaux de neurones??)
L2 p.62-99: audiovisuel (réduire à 20 slides)
L2 p.100-121: synthèse expressive
style tokens
voice conversion
évaluation objective: naturalness, speaker similarity
L3 p.2-56: évaluation intelligibilité audiovisuelle + expressivité -> réduire à 5 slides
150 slides -> 5 heures -> 3h20 (IDMC) 5h (FST)

lab 2 here: voice conversion, expressivity

speechbrain: fastspeech2/tacotron2, end-to-end system with both character and phoneme inputs
voice conversion: make your own deepfake!
1 lab = 1 notebook
ask students to submit by the end of the current week (Sun)
1 grade per lab
lab mark 40%
exam 60%
